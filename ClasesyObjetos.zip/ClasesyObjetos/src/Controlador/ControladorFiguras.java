package Controlador;

import modelo.CalcularAreas;
import modelo.circulo;
import modelo.cuadrado;
import modelo.triangulo;
import vista.Vista2;


public class ControladorFiguras {
    private CalcularAreas calcularAreas;
    private Vista2 vista;

    public ControladorFiguras(CalcularAreas calcularAreas, Vista2 vista) {
        this.calcularAreas = calcularAreas;
        this.vista = vista;
    }
    public void ejecutar() {
        String opcion;
        double area;

        do {
            opcion = vista.listaDesplegable("Circulo,Cuadrado,Triangulo,Salir");

            if (opcion == null) {
                break;
            }

            switch (opcion) {
                case "Circulo":
                    area = calcularAreas.calcularArea(
                            new circulo(vista.leerFloat("Ingresa el radio")));

                    vista.imprimeSalida("Area del circulo: " + area);
                    break;

                case "Cuadrado":
                    area = calcularAreas.calcularArea(
                            new cuadrado(vista.leerFloat("Ingresa el lado")));

                    vista.imprimeSalida("Area del cuadrado " + area);
                    break;

                case "Triangulo":
                    area = calcularAreas.calcularArea(
                            new triangulo(vista.leerFloat("Ingresa la base"), vista.leerFloat("Ingresa la altura")));

                    vista.imprimeSalida("Area del triangulo " + area);
                    break;

                case "Salir":
                    vista.imprimeSalida("Fin del programa");
                    break;
            }

        } while (!opcion.equals("Salir"));
    }
}

