package modelo;

public class circulo {
    private float radio;

    public circulo() {
    }

    public circulo(float radio) {
        this.radio = radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    }
