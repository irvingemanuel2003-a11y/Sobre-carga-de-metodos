package modelo;

public class cuadrado {
    private float lado;

    public cuadrado() {
    }

    public cuadrado(float lado) {
        this.lado = lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    public float getLado() {
        return lado;
    }


}
