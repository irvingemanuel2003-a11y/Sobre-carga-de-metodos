package modelo;

public class CalcularAreas {

    public double calcularArea(circulo figura) {
        return Math.PI * Math.pow(figura.getRadio(), 2);
    }

    public double calcularArea(cuadrado figura) {
        return Math.pow(figura.getLado(), 2);
    }

    public double calcularArea(triangulo figura) {
        return figura.getBase() * figura.getAltura() / 2;
    }
}
