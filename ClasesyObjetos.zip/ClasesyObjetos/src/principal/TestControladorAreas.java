package principal;

import Controlador.ControladorFiguras;
import modelo.CalcularAreas;
import vista.Vista2;

public class TestControladorAreas {
    public static void main(String[] args) {
        CalcularAreas modelo = new CalcularAreas();
        Vista2 vista = new Vista2();

        ControladorFiguras controladorFiguras = new ControladorFiguras(modelo, vista);

        controladorFiguras.ejecutar();
    }
}
