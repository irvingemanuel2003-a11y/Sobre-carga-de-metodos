package controlador;

import modelo.TarifaEstacionamiento;
import vista.Vista2;

public class ControladorTarifaEstacionamiento {

    private Vista2 vista;

    public ControladorTarifaEstacionamiento(Vista2 vista) {
        this.vista = vista;
    }

    public void ejecutar() {
        String opcion;
        double importe;

        do {
            opcion = vista.listaDesplegable("Tarifa base de $20,Tarifa personalizada,Tarifa con descuento,Salir");
            switch (opcion) {
                case "Tarifa base de $20":
                    importe = TarifaEstacionamiento.calcularImporte(vista.leerByte("Ingresa las horas de estacionamiento:"));
                    vista.imprimeSalida("Importe a pagar: $" + importe);
                    break;

                case "Tarifa personalizada":
                    importe = TarifaEstacionamiento.calcularImporte(vista.leerByte("Ingresa las horas:"),
                            vista.leerDouble("Ingresa la tarifa por hora:"));
                    vista.imprimeSalida("Importe a pagar: $" + importe);
                    break;

                case "Tarifa con descuento":
                    importe = TarifaEstacionamiento.calcularImporte(vista.leerByte("Ingresa las horas:"),
                            vista.leerDouble("Ingresa la tarifa por hora:"),
                            vista.leerPorcentaje("Ingresa el descuento en porcentaje:"));
                    vista.imprimeSalida("Importe con descuento: $" + importe);
                    break;

                case "Salir":
                    vista.imprimeSalida("Fin del programa");
                    break;
            }
        } while (!opcion.equals("Salir"));
    }
}
