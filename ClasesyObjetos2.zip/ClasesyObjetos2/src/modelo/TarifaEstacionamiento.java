package modelo;

public class TarifaEstacionamiento {

    private static final double TARIFA_BASE = 20.0;

    public static double calcularImporte(byte horas) {
        return horas * TARIFA_BASE;
    }

    public static double calcularImporte(byte horas, double tarifaPorHora) {
        return horas * tarifaPorHora;
    }

    public static double calcularImporte(byte horas, double tarifaPorHora,double descuentoPorcentaje) {
        double importe = horas * tarifaPorHora;
        return importe - (importe * descuentoPorcentaje / 100);
    }
}
