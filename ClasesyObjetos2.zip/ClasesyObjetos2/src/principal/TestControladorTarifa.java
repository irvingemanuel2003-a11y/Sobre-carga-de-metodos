package principal;

import controlador.ControladorTarifaEstacionamiento;
import vista.Vista2;

public class TestControladorTarifa {
    public static void main (String[]args){
        Vista2 vista = new Vista2();
        ControladorTarifaEstacionamiento controlador = new ControladorTarifaEstacionamiento(vista);
        controlador.ejecutar();
    }
}
