package vista;

import javax.swing.JOptionPane;

public class Vista2 {

    public void imprimeError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "ERROR", JOptionPane.ERROR_MESSAGE);
    }

    public void imprimeSalida(String mensaje) {JOptionPane.showMessageDialog(null, mensaje, "Salida",
            JOptionPane.INFORMATION_MESSAGE);
    }

    public byte leerByte(String mensaje) {
        while (true)
            try {
                byte dato = Byte.parseByte(JOptionPane.showInputDialog(mensaje));
                if (dato > 0) {
                    return dato;
                } else {
                    imprimeError("El dato debe ser positivo");
                }
            } catch (NumberFormatException e) {
                imprimeError("Ingresa un byte válido");
            }
    }

    public double leerDouble(String mensaje) {
        while (true)
            try {
                double dato = Double.parseDouble(JOptionPane.showInputDialog(mensaje));
                if (dato > 0) {
                    return dato;
                } else {
                    imprimeError("El dato debe ser positivo");
                }
            } catch (NumberFormatException e) {
                imprimeError("Ingresa un número válido");
            }
    }

    public double leerPorcentaje(String mensaje) {
        while (true)
            try {
                double dato = Double.parseDouble(JOptionPane.showInputDialog(mensaje));

                if (dato >= 0 && dato <= 100) {
                    return dato;
                } else {
                    imprimeError("El descuento debe estar entre 0 y 100");
                }
            } catch (NumberFormatException e) {
                imprimeError("Ingresa un porcentaje válido");
            }
    }

    public String listaDesplegable(String opciones) {
        Object seleccion = JOptionPane.showInputDialog(null, "Selecciona una opción:",
                "Menú de estacionamiento", JOptionPane.QUESTION_MESSAGE, null, opciones.split(","), null);
        return seleccion.toString();
    }
}
