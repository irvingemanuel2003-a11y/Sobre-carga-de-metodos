package Modelo;

public class Sumas {

    //sobrecarga de metodos de clase
    public static byte sumar(byte dato1, byte dato2) {
        return (byte) (dato1 + dato2);
    }

    public static int sumar(byte dato1, byte dato2, int dato3) {
        return dato1 + dato2 + dato3;
    }

    public static float sumar(float dato1, float dato2) {
        return dato1 + dato2;
    }

    public static double sumar(float dato1, byte dato2, int dato3) {
        return dato1 + dato2 + dato3;
    }

    public static int sumar(byte dato1, short dato2, int dato3) {
        return dato1 + dato2 + dato3;
    }
}