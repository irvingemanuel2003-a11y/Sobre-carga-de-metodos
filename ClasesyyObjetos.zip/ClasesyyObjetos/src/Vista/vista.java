package Vista;

import javax.swing.*;

public class vista {

    public static void imprimeError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "ERROR",
                JOptionPane.ERROR_MESSAGE);
    }

    public static void imprimeSalida(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Salida",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public static void imprimeDatos(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje);
    }

    public static int leerInt() {
        while (true)
            try {
                return Integer.parseInt(
                        JOptionPane.showInputDialog("Ingresa un int:"));
            } catch (NumberFormatException e) {
                imprimeError("Dato int incorrecto");
            }
    }

    public static short leerShort() {
        while (true)
            try {
                return Short.parseShort(
                        JOptionPane.showInputDialog("Ingresa un short:"));
            } catch (NumberFormatException e) {
                imprimeError("Dato short incorrecto");
            }
    }

    public static byte leerByte() {
        while (true)
            try {
                return Byte.parseByte(
                        JOptionPane.showInputDialog("Ingresa un byte:"));
            } catch (NumberFormatException e) {
                imprimeError("Dato byte incorrecto");
            }
    }

    public static float leerFloat() {
        while (true)
            try {
                return Float.parseFloat(
                        JOptionPane.showInputDialog("Ingresa un float:"));
            } catch (NumberFormatException e) {
                imprimeError("Dato float incorrecto");
            }
    }

    public static String listaDesplegable(String opciones) {
        Object seleccion = JOptionPane.showInputDialog(null, "Selecciona una opción:", "Menú de sumas", JOptionPane.QUESTION_MESSAGE, null, opciones.split(","), null);

        if (seleccion == null)
            return null;

        return seleccion.toString();
    }
}
