package Principal;

import Controlador.ControladorSuma;

public class TestControladorSuma
{
    public static void main(String[] args) {
        ControladorSuma.menu();
    }
}


