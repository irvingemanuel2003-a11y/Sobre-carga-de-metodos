package Controlador;

import Modelo.Sumas;
import Vista.vista;

public class ControladorSuma {
    public static void menu() {
        String opcion;
        do {
            opcion = vista.listaDesplegable("Sumar 2 bytes," +
                    "Sumar 2 bytes y 1 int," + "Sumar 2 float," +
                    "Sumar 1 float 1 byte y 1 int," +
                    "Sumar 1 byte 1 short y 1 int," + "Salir");
            switch (opcion) {
                case "Sumar 2 bytes":
                    vista.imprimeDatos("Resultado: " +
                            Sumas.sumar(vista.leerByte(), vista.leerByte()));
                    break;

                case "Sumar 2 bytes y 1 int":
                    vista.imprimeDatos("Resultado: " +
                            Sumas.sumar(vista.leerByte(), vista.leerByte(),
                                    vista.leerInt()));
                    break;

                case "Sumar 2 float":
                    vista.imprimeDatos("Resultado: " +
                            Sumas.sumar(vista.leerFloat(), vista.leerFloat()));
                    break;

                case "Sumar 1 float 1 byte y 1 int":
                    vista.imprimeDatos("Resultado: " +
                            Sumas.sumar(vista.leerFloat(), vista.leerByte(), vista.leerInt()));
                    break;

                case "Sumar 1 byte 1 short y 1 int":
                    vista.imprimeDatos("Resultado: " +
                            Sumas.sumar(vista.leerByte(), vista.leerShort(), vista.leerInt()));
                    break;

                case "Salir":
                    vista.imprimeSalida("Fin del programa");
                    break;
            }

        } while (!opcion.equals("Salir"));
    }
}
